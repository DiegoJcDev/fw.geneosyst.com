<?php
require 'stripe_config.php';

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$priceId = $input['price_id'] ?? null;
$email = $input['email'] ?? null;

if (!$priceId || !$email) {
  echo json_encode(['success' => false, 'message' => 'Faltan datos obligatorios']);
  exit;
}

try {
  $session = \Stripe\Checkout\Session::create([
    'mode' => 'subscription',
    'line_items' => [[ 'price' => $priceId, 'quantity' => 1 ]],
    'success_url' => 'https://tu-dominio.com/pago_exitoso.php?session_id={CHECKOUT_SESSION_ID}',
    'cancel_url' => 'https://tu-dominio.com/pago_cancelado.php',
    'customer_email' => $email,
  ]);

  echo json_encode(['success' => true, 'url' => $session->url]);
} catch (Exception $e) {
  echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
