<?php
require_once __DIR__ . '/stripe-php/init.php';

\Stripe\Stripe::setApiKey('sk_test_XXXXXXXXXXXXXXXXXXXXXXXX'); // Sustituye por tu clave secreta real
